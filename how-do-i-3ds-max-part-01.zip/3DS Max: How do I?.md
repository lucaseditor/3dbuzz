# 3DS Max: How do I?
The “How Do I?” series is a collection of short tip-based videos covering very specific topics in a given application. The topics themselves were sent in or collected from users across the internet, and we in turn create a video which answers the question as concisely as possible. These videos are a great way to pick up little tips and tricks, or just as a way to get to know aspects of an application with which you may not yet be familiar.

## How do I?
How do I?

### Use the Autobackup feature?
How to make the most of the Autobackup feature of 3ds Max.

### Move objects in screen space?
How you can change the options for the Move Tool to move objects in Screen space.

### Change the order of Modifiers?
This video covers the process and importance of changing the order of modifiers in the Stack.

### Use the Hold and Fetch commands?
A look at Holding and Fetching your scene, and how these commands are used.

### Link (Parent) objects in 3ds Max?
A discussion of some of the ways you can link - or parent - objects together in 3ds Max.

### Create Compound Shapes?
A look at how you can create multi-spline objects without having to attach them later.

### Create Custom Grids?
How you can create grids that have different orientation from the home or orthogonal view grids.

### Convert an Object to an Editable Poly?
A brief discussion of a few ways to convert a primitive to an editable poly for modeling purposes.

### Rotate About Other Objects (Pick RCS)?
Using the Pick Reference Coordinate System to rotate about the pivot of other objects.

